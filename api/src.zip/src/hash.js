/**
 * Created by user on 8/5/2021.
 */
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");

/*bcrypt.hash('123456', 10, function(err, hash) {
    console.log(hash);
});*/


/*bcrypt.compare('1234567', '$2a$10$Q09Mzkit4wHv6vcZU5M2I.gmRNJTL78pPMVXhjgE9vTFYAtlkc57S', function(err, res) {
    console.log(res);
});*/



